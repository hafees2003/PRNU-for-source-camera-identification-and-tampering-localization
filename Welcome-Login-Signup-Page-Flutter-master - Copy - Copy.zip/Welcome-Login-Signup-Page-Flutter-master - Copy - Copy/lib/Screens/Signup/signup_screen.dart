import 'dart:convert';
import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;
import 'package:flutter_nsd/flutter_nsd.dart';
import 'package:animate_do/animate_do.dart';
import 'package:flutter_spinkit/flutter_spinkit.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:flutter/foundation.dart' show kIsWeb;

class SignUpScreen extends StatefulWidget {
  @override
  _SignUpScreenState createState() => _SignUpScreenState();
}

class _SignUpScreenState extends State<SignUpScreen> with SingleTickerProviderStateMixin {
  bool _isPasswordVisible = false;
  bool _isConfirmPasswordVisible = false;
  bool isLoading = false;
  bool isSearchingForServer = true;

  final TextEditingController emailController = TextEditingController();
  final TextEditingController passwordController = TextEditingController();
  final TextEditingController confirmPasswordController = TextEditingController();
  final TextEditingController manualIpController = TextEditingController(text: "");

  String apiUrl = "http://localhost:8080/api/auth/signup";
  FlutterNsd? flutterNsd;

  late AnimationController _animationController;
  late Animation<double> _glowAnimation;

  @override
  void initState() {
    super.initState();
    if (!kIsWeb) {
      flutterNsd = FlutterNsd();
    }
    discoverBackendService();

    _animationController = AnimationController(
      vsync: this,
      duration: Duration(seconds: 4),
    )..repeat(reverse: true);
    _glowAnimation = Tween<double>(begin: 0.05, end: 0.15).animate(
      CurvedAnimation(parent: _animationController, curve: Curves.easeInOut),
    );
  }

  Future<void> discoverBackendService() async {
    if (kIsWeb) {
      setState(() => isSearchingForServer = false);
      return;
    }
    try {
      await flutterNsd!.discoverServices('_http._tcp.');
      flutterNsd!.stream.listen(
        (NsdServiceInfo service) {
          final ip = service.hostname?.replaceAll('.local', '') ?? 'localhost';
          final port = service.port ?? 8080;
          setState(() {
            apiUrl = "http://$ip:$port/api/auth/signup";
            isSearchingForServer = false;
          });
          flutterNsd!.stopDiscovery();
        },
        onError: (e) => setState(() => isSearchingForServer = false),
        onDone: () => setState(() => isSearchingForServer = false),
      );
    } catch (e) {
      setState(() => isSearchingForServer = false);
    }
  }

  Future<void> signUp() async {
    if (isSearchingForServer) return;

    setState(() => isLoading = true);
    String effectiveUrl = manualIpController.text.isNotEmpty
        ? "http://${manualIpController.text.trim()}:8080/api/auth/signup"
        : apiUrl;

    if (emailController.text.trim().isEmpty ||
        passwordController.text.trim().isEmpty ||
        confirmPasswordController.text.trim().isEmpty) {
      ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text("All fields are required!")));
      setState(() => isLoading = false);
      return;
    }

    if (passwordController.text != confirmPasswordController.text) {
      ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text("Passwords do not match!")));
      setState(() => isLoading = false);
      return;
    }

    try {
      final response = await http.post(
        Uri.parse(effectiveUrl),
        headers: {"Content-Type": "application/json"},
        body: jsonEncode({
          "email": emailController.text.trim(),
          "password": passwordController.text.trim(),
        }),
      );

      setState(() => isLoading = false);
      final responseData = jsonDecode(response.body);

      // Check for successful signup and navigate
      if (response.statusCode == 201 && responseData["message"] == "Signup successful!") {
        // Show success message
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(content: Text("Signup successful! Redirecting to login...")),
        );
        
        // Delay slightly to show the message, then navigate
        await Future.delayed(Duration(seconds: 1));
        
        if (mounted) {  // Ensure widget is still mounted before navigation
          Navigator.pushReplacementNamed(context, '/login');
        }
      } else {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(content: Text(responseData["message"] ?? "Signup failed. Try again!")),
        );
      }
    } catch (error) {
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text("Network error: $error")),
      );
      setState(() => isLoading = false);
    }
  }

  @override
  void dispose() {
    emailController.dispose();
    passwordController.dispose();
    confirmPasswordController.dispose();
    manualIpController.dispose();
    if (!kIsWeb && flutterNsd != null) flutterNsd!.stopDiscovery();
    _animationController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Stack(
        children: [
          Stack(
            children: [
              Image.asset(
                'assets/images/holographic_background.jpg',
                fit: BoxFit.cover,
                width: double.infinity,
                height: double.infinity,
                errorBuilder: (context, error, stackTrace) => Container(
                  decoration: BoxDecoration(
                    gradient: RadialGradient(
                      center: Alignment.center,
                      radius: 1.5,
                      colors: [Color(0xFF003366), Color(0xFF006699), Color(0xFF0099cc)],
                    ),
                  ),
                ),
              ),
              AnimatedBuilder(
                animation: _glowAnimation,
                builder: (context, child) {
                  return Container(
                    decoration: BoxDecoration(
                      gradient: RadialGradient(
                        center: Alignment.center,
                        radius: 2.0,
                        colors: [
                          Colors.transparent,
                          Colors.blue.withOpacity(_glowAnimation.value),
                        ],
                      ),
                    ),
                  );
                },
              ),
            ],
          ),
          Center(
            child: FadeIn(
              duration: Duration(seconds: 1),
              child: Container(
                width: MediaQuery.of(context).size.width * 0.5,
                constraints: BoxConstraints(maxWidth: 500),
                padding: EdgeInsets.all(30),
                decoration: BoxDecoration(
                  gradient: LinearGradient(
                    colors: [Color(0xFF333333), Color(0xFF111111)],
                  ),
                  borderRadius: BorderRadius.circular(20),
                  boxShadow: [
                    BoxShadow(
                      color: Colors.black.withOpacity(0.5),
                      offset: Offset(0, 5),
                      blurRadius: 10,
                    ),
                    BoxShadow(
                      color: Colors.blue.withOpacity(0.2),
                      spreadRadius: 5,
                      blurRadius: 20,
                    ),
                  ],
                ),
                child: Column(
                  mainAxisSize: MainAxisSize.min,
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(
                      "Create an account",
                      style: GoogleFonts.orbitron(
                        fontSize: 32,
                        fontWeight: FontWeight.bold,
                        color: Colors.white,
                      ),
                    ),
                    SizedBox(height: 10),
                    Text(
                      "Please fill in the details to sign up",
                      style: GoogleFonts.openSans(fontSize: 16, color: Colors.white70),
                    ),
                    SizedBox(height: 30),
                    if (isSearchingForServer) ...[
                      Center(child: SpinKitWave(color: Colors.white, size: 50.0)),
                      SizedBox(height: 20),
                      Center(
                        child: Text(
                          "Searching for server...",
                          style: GoogleFonts.openSans(fontSize: 14, color: Colors.white70),
                        ),
                      ),
                    ] else ...[
                      if (apiUrl.contains("localhost")) ...[
                        _buildInputField(
                          controller: manualIpController,
                          label: "Enter Backend IP (e.g., 192.168.x.x)",
                          icon: Icons.vpn_key,
                        ),
                        SizedBox(height: 20),
                      ],
                      _buildInputField(
                        controller: emailController,
                        label: "Email",
                        icon: Icons.email,
                      ),
                      SizedBox(height: 20),
                      _buildInputField(
                        controller: passwordController,
                        label: "Password",
                        icon: Icons.lock,
                        obscureText: !_isPasswordVisible,
                        suffixIcon: IconButton(
                          icon: Icon(
                            _isPasswordVisible ? Icons.visibility : Icons.visibility_off,
                            color: Colors.white70,
                          ),
                          onPressed: () => setState(() => _isPasswordVisible = !_isPasswordVisible),
                        ),
                      ),
                      SizedBox(height: 20),
                      _buildInputField(
                        controller: confirmPasswordController,
                        label: "Confirm Password",
                        icon: Icons.lock,
                        obscureText: !_isConfirmPasswordVisible,
                        suffixIcon: IconButton(
                          icon: Icon(
                            _isConfirmPasswordVisible ? Icons.visibility : Icons.visibility_off,
                            color: Colors.white70,
                          ),
                          onPressed: () => setState(() => _isConfirmPasswordVisible = !_isConfirmPasswordVisible),
                        ),
                      ),
                      SizedBox(height: 30),
                      ElevatedButton(
                        onPressed: isLoading || isSearchingForServer ? null : signUp,
                        style: ElevatedButton.styleFrom(
                          backgroundColor: Colors.transparent,
                          padding: EdgeInsets.zero,
                          shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(10)),
                        ),
                        child: Ink(
                          decoration: BoxDecoration(
                            gradient: LinearGradient(
                              colors: [Color(0xFF00B4D8), Color(0xFF0077B6)],
                            ),
                            borderRadius: BorderRadius.circular(10),
                          ),
                          child: Container(
                            width: double.infinity,
                            padding: EdgeInsets.symmetric(vertical: 15),
                            child: Center(
                              child: isLoading
                                  ? SpinKitWave(color: Colors.white, size: 20.0)
                                  : Text(
                                      "Sign Up",
                                      style: GoogleFonts.openSans(
                                        fontSize: 18,
                                        fontWeight: FontWeight.bold,
                                        color: Colors.white,
                                      ),
                                    ),
                            ),
                          ),
                        ),
                      ),
                    ],
                  ],
                ),
              ),
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildInputField({
    required TextEditingController controller,
    required String label,
    required IconData icon,
    bool obscureText = false,
    Widget? suffixIcon,
  }) {
    return TextField(
      controller: controller,
      obscureText: obscureText,
      style: TextStyle(color: Colors.white),
      decoration: InputDecoration(
        labelText: label,
        labelStyle: GoogleFonts.openSans(color: Colors.white70),
        prefixIcon: Icon(icon, color: Colors.white70),
        suffixIcon: suffixIcon,
        enabledBorder: OutlineInputBorder(
          borderSide: BorderSide(color: Colors.white70, width: 1),
          borderRadius: BorderRadius.circular(10),
        ),
        focusedBorder: OutlineInputBorder(
          borderSide: BorderSide(color: Color(0xFF00B4D8), width: 2),
          borderRadius: BorderRadius.circular(10),
        ),
      ),
    );
  }
}