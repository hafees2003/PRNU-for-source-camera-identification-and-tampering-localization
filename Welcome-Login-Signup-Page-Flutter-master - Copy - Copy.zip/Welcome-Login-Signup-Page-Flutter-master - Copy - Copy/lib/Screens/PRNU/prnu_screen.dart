import 'dart:convert';
import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;
import 'package:shared_preferences/shared_preferences.dart';
import 'package:file_picker/file_picker.dart';
import 'package:fl_chart/fl_chart.dart';
import 'package:google_fonts/google_fonts.dart';

class PRNUScreen extends StatefulWidget {
  @override
  _PRNUScreenState createState() => _PRNUScreenState();
}

class _PRNUScreenState extends State<PRNUScreen> with TickerProviderStateMixin {
  bool isLoading = false;
  String? uploadedImagePath;
  late AnimationController _glowController;
  late Animation<double> _glowAnimation;

  @override
  void initState() {
    super.initState();
    _glowController = AnimationController(
      vsync: this,
      duration: const Duration(seconds: 2),
    )..repeat(reverse: true);
    _glowAnimation = Tween<double>(begin: 5, end: 15).animate(
      CurvedAnimation(parent: _glowController, curve: Curves.easeInOut),
    );
  }

  @override
  void dispose() {
    _glowController.dispose();
    super.dispose();
  }

  Future<void> uploadImage() async {
    final result = await FilePicker.platform.pickFiles(type: FileType.image);
    if (result == null || result.files.isEmpty) {
      ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text("No image selected!")));
      return;
    }
    setState(() {
      uploadedImagePath = result.files.first.path;
      print("Image uploaded: $uploadedImagePath");
    });
    ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text("Image uploaded successfully!")));
  }

  Future<void> evaluatePRNU() async {
    if (uploadedImagePath == null) {
      ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text("Please upload an image first!")));
      return;
    }

    setState(() => isLoading = true);

    final prefs = await SharedPreferences.getInstance();
    final token = prefs.getString("jwt_token");
    if (token == null) {
      ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text("Please log in first!")));
      setState(() => isLoading = false);
      return;
    }

    final request = http.MultipartRequest(
      "POST",
      Uri.parse("http://localhost:8080/api/prnu/predict"),
    );
    request.headers["Authorization"] = "Bearer $token";
    request.files.add(await http.MultipartFile.fromPath("image", uploadedImagePath!));

    try {
      print("Sending PRNU prediction request with token: $token");
      final response = await request.send();
      final responseBody = await response.stream.bytesToString();
      print("Received response: ${response.statusCode}, Body: $responseBody");

      setState(() => isLoading = false);

      if (response.statusCode == 200) {
        final responseData = jsonDecode(responseBody);
        String originalUrl = responseData["original_url"];
        String maskUrl = responseData["mask_url"];
        String predictedCamera = responseData["prediction"]["camera"];
        List<double> confidences = List<double>.from(responseData["prediction"]["confidences"]);
        List<String> cameraLabels = List<String>.from(responseData["prediction"]["camera_labels"]); // Fetch dynamic labels
        print("✅ PRNU prediction successful: original=$originalUrl, mask=$maskUrl, camera=$predictedCamera");
        _showPRNUPopup(context, originalUrl, maskUrl, predictedCamera, confidences, cameraLabels);
      } else {
        String errorMessage;
        try {
          final responseData = jsonDecode(responseBody);
          errorMessage = responseData["message"] ?? "Unknown error";
        } catch (e) {
          errorMessage = responseBody;
        }
        print("❌ PRNU prediction failed: ${response.statusCode}, $errorMessage");
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(content: Text("Failed to predict camera: $errorMessage")),
        );
      }
    } catch (e) {
      print("❌ Network Error: $e");
      ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text("Network error: $e")));
      setState(() => isLoading = false);
    }
  }

  void _showPRNUPopup(BuildContext context, String originalUrl, String maskUrl, String predictedCamera, List<double> confidences, List<String> cameraLabels) {
    showDialog(
      context: context,
      builder: (BuildContext context) {
        return AlertDialog(
          title: Text("PRNU Source Camera Identification", style: GoogleFonts.orbitron(fontWeight: FontWeight.bold)),
          content: SingleChildScrollView(
            child: Column(
              mainAxisSize: MainAxisSize.min,
              children: [
                Row(
                  mainAxisSize: MainAxisSize.min,
                  children: [
                    Column(
                      children: [
                        Text("Original Image", style: GoogleFonts.orbitron()),
                        Image.network(
                          originalUrl,
                          width: 200,
                          errorBuilder: (context, error, stackTrace) => Text("Failed to load original: $error"),
                        ),
                      ],
                    ),
                    SizedBox(width: 20),
                    Column(
                      children: [
                        Text("PRNU Heatmap", style: GoogleFonts.orbitron()),
                        Image.network(
                          maskUrl,
                          width: 200,
                          errorBuilder: (context, error, stackTrace) => Text("Failed to load mask: $error"),
                        ),
                      ],
                    ),
                  ],
                ),
                SizedBox(height: 20),
                Text("Predicted Camera: $predictedCamera", style: GoogleFonts.orbitron(fontWeight: FontWeight.bold)),
                SizedBox(height: 10),
                SizedBox(
                  height: 200,
                  width: 300,
                  child: BarChart(
                    BarChartData(
                      alignment: BarChartAlignment.spaceAround,
                      barGroups: cameraLabels.asMap().entries.map((entry) {
                        return BarChartGroupData(
                          x: entry.key,
                          barRods: [
                            BarChartRodData(
                              toY: confidences[entry.key],
                              color: Colors.blue,
                              width: 16,
                            ),
                          ],
                        );
                      }).toList(),
                      titlesData: FlTitlesData(
                        bottomTitles: AxisTitles(
                          sideTitles: SideTitles(
                            showTitles: true,
                            getTitlesWidget: (value, meta) => Transform.rotate(
                              angle: -45 * 3.14159 / 180,
                              child: Text(
                                cameraLabels[value.toInt()],
                                style: GoogleFonts.orbitron(fontSize: 12),
                                textAlign: TextAlign.center,
                              ),
                            ),
                            reservedSize: 40,
                          ),
                        ),
                        leftTitles: AxisTitles(
                          sideTitles: SideTitles(showTitles: true, reservedSize: 40),
                        ),
                      ),
                      borderData: FlBorderData(show: false),
                      maxY: 1.0,
                    ),
                  ),
                ),
              ],
            ),
          ),
          actions: [
            TextButton(
              onPressed: () => Navigator.of(context).pop(),
              child: Text("Close", style: GoogleFonts.orbitron()),
            ),
          ],
        );
      },
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text("PRNU Source Camera Identification", style: GoogleFonts.orbitron()),
        backgroundColor: Colors.blueGrey[900],
      ),
      body: Container(
        width: double.infinity,
        height: double.infinity,
        decoration: BoxDecoration(
          image: DecorationImage(
            image: AssetImage('assets/images/holographic_background.jpg'),
            fit: BoxFit.cover,
          ),
        ),
        child: Center(
          child: Column(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              _buildAnimatedButton(
                text: "Upload Image",
                imagePath: 'assets/images/upload_button_background.jpg',
                icon: Icons.upload,
                onTap: uploadImage,
              ),
              SizedBox(height: 40),
              _buildAnimatedButton(
                text: "Evaluate",
                imagePath: 'assets/images/evaluate_button_background.jpg',
                icon: Icons.search,
                onTap: evaluatePRNU,
              ),
              if (isLoading)
                Padding(
                  padding: EdgeInsets.only(top: 20),
                  child: CircularProgressIndicator(color: Colors.white),
                ),
            ],
          ),
        ),
      ),
    );
  }

  Widget _buildAnimatedButton({required String text, required String imagePath, required IconData icon, required VoidCallback onTap}) {
    return GestureDetector(
      onTap: onTap,
      child: AnimatedBuilder(
        animation: _glowAnimation,
        builder: (context, child) {
          return Container(
            width: 400,
            height: 200,
            decoration: BoxDecoration(
              image: DecorationImage(
                image: AssetImage(imagePath),
                fit: BoxFit.cover,
              ),
              borderRadius: BorderRadius.circular(15),
              border: Border.all(
                color: const Color(0xFF00B4D8),
                width: 3,
              ),
              boxShadow: [
                BoxShadow(
                  color: const Color(0xFF00B4D8).withOpacity(0.4),
                  spreadRadius: _glowAnimation.value,
                  blurRadius: _glowAnimation.value * 2,
                ),
              ],
            ),
            child: Stack(
              alignment: Alignment.center,
              children: [
                Positioned(
                  top: 60,
                  child: Icon(
                    icon,
                    color: Colors.white,
                    size: 40,
                  ),
                ),
                Center(
                  child: Text(
                    text,
                    style: GoogleFonts.orbitron(
                      fontSize: 24,
                      color: Colors.white,
                      fontWeight: FontWeight.bold,
                      shadows: [
                        Shadow(
                          color: Colors.black,
                          blurRadius: 4,
                          offset: Offset(2, 2),
                        ),
                      ],
                    ),
                    textAlign: TextAlign.center,
                  ),
                ),
              ],
            ),
          );
        },
      ),
    );
  }
}