import 'dart:convert';
import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;
import 'package:flutter_nsd/flutter_nsd.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:animate_do/animate_do.dart';
import 'package:flutter_spinkit/flutter_spinkit.dart';
import 'package:google_fonts/google_fonts.dart';
import '../Home/home_screen.dart';
import 'package:flutter/foundation.dart' show kIsWeb;

class LoginScreen extends StatefulWidget {
  @override
  _LoginScreenState createState() => _LoginScreenState();
}

class _LoginScreenState extends State<LoginScreen> with SingleTickerProviderStateMixin {
  bool _isPasswordVisible = false;
  bool isLoading = false;
  bool isSearchingForServer = true;

  final TextEditingController emailController = TextEditingController();
  final TextEditingController passwordController = TextEditingController();
  final TextEditingController manualIpController = TextEditingController(text: "");

  String apiUrl = "http://localhost:8080/api/auth/login";
  FlutterNsd? flutterNsd;

  late AnimationController _animationController;
  late Animation<double> _glowAnimation;

  @override
  void initState() {
    super.initState();
    if (!kIsWeb) {
      flutterNsd = FlutterNsd();
    }
    discoverBackendService();

    _animationController = AnimationController(
      vsync: this,
      duration: Duration(seconds: 4),
    )..repeat(reverse: true);
    _glowAnimation = Tween<double>(begin: 0.05, end: 0.15).animate(
      CurvedAnimation(parent: _animationController, curve: Curves.easeInOut),
    );
  }

  Future<void> discoverBackendService() async {
    if (kIsWeb) {
      setState(() => isSearchingForServer = false);
      return;
    }
    try {
      await flutterNsd!.discoverServices('_http._tcp.');
      flutterNsd!.stream.listen(
        (NsdServiceInfo service) {
          final ip = service.hostname?.replaceAll('.local', '') ?? 'localhost';
          final port = service.port ?? 8080;
          setState(() {
            apiUrl = "http://$ip:$port/api/auth/login";
            isSearchingForServer = false;
          });
          flutterNsd!.stopDiscovery();
        },
        onError: (e) => setState(() => isSearchingForServer = false),
        onDone: () => setState(() => isSearchingForServer = false),
      );
    } catch (e) {
      setState(() => isSearchingForServer = false);
    }
  }

  Future<void> login() async {
    if (isSearchingForServer) return;

    setState(() => isLoading = true);
    String effectiveUrl = manualIpController.text.isNotEmpty
        ? "http://${manualIpController.text.trim()}:8080/api/auth/login"
        : apiUrl;

    try {
      final response = await http.post(
        Uri.parse(effectiveUrl),
        headers: {"Content-Type": "application/json"},
        body: jsonEncode({
          "email": emailController.text.trim(),
          "password": passwordController.text.trim(),
        }),
      );

      setState(() => isLoading = false);
      final responseData = jsonDecode(response.body);
      if (response.statusCode == 200 && responseData["message"] == "Login successful") {
        final token = responseData["token"];
        final prefs = await SharedPreferences.getInstance();
        await prefs.setString("jwt_token", token);
        Navigator.pushReplacement(
          context,
          MaterialPageRoute(builder: (_) => HomeScreen(apiUrl: effectiveUrl.replaceAll('/api/auth/login', ''))),
        );
      } else {
        _showErrorSnackBar(responseData["message"] ?? "Invalid email or password!");
      }
    } catch (error) {
      _showErrorSnackBar("Network error: $error");
      setState(() => isLoading = false);
    }
  }

  void _showErrorSnackBar(String message) {
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(
        content: Text(
          message,
          style: GoogleFonts.openSans(color: Colors.white),
        ),
        backgroundColor: Colors.red,
        behavior: SnackBarBehavior.floating, // Makes the SnackBar float
        margin: EdgeInsets.only(
          left: MediaQuery.of(context).size.width * 0.25, // Center horizontally near the container (50% width, offset by 25%)
          right: MediaQuery.of(context).size.width * 0.25,
          bottom: 100, // Position it above the container (adjust as needed)
        ),
        duration: Duration(seconds: 3),
      ),
    );
  }

  @override
  void dispose() {
    emailController.dispose();
    passwordController.dispose();
    manualIpController.dispose();
    if (!kIsWeb && flutterNsd != null) flutterNsd!.stopDiscovery();
    _animationController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Stack(
        children: [
          Stack(
            children: [
              Image.asset(
                'assets/images/holographic_background.jpg',
                fit: BoxFit.cover,
                width: double.infinity,
                height: double.infinity,
                errorBuilder: (context, error, stackTrace) => Container(
                  decoration: BoxDecoration(
                    gradient: RadialGradient(
                      center: Alignment.center,
                      radius: 1.5,
                      colors: [Color(0xFF003366), Color(0xFF006699), Color(0xFF0099cc)],
                    ),
                  ),
                ),
              ),
              AnimatedBuilder(
                animation: _glowAnimation,
                builder: (context, child) {
                  return Container(
                    decoration: BoxDecoration(
                      gradient: RadialGradient(
                        center: Alignment.center,
                        radius: 2.0,
                        colors: [
                          Colors.transparent,
                          Colors.blue.withOpacity(_glowAnimation.value),
                        ],
                      ),
                    ),
                  );
                },
              ),
            ],
          ),
          Center(
            child: FadeIn(
              duration: Duration(seconds: 1),
              child: Container(
                width: MediaQuery.of(context).size.width * 0.5,
                constraints: BoxConstraints(maxWidth: 500),
                padding: EdgeInsets.all(30),
                decoration: BoxDecoration(
                  gradient: LinearGradient(
                    colors: [Color(0xFF333333), Color(0xFF111111)],
                  ),
                  borderRadius: BorderRadius.circular(20),
                  boxShadow: [
                    BoxShadow(
                      color: Colors.black.withOpacity(0.5),
                      offset: Offset(0, 5),
                      blurRadius: 10,
                    ),
                    BoxShadow(
                      color: Colors.blue.withOpacity(0.2),
                      spreadRadius: 5,
                      blurRadius: 20,
                    ),
                  ],
                ),
                child: Column(
                  mainAxisSize: MainAxisSize.min,
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(
                      "Welcome back!",
                      style: GoogleFonts.orbitron(
                        fontSize: 32,
                        fontWeight: FontWeight.bold,
                        color: Colors.white,
                      ),
                    ),
                    SizedBox(height: 10),
                    Text(
                      "Please enter your details",
                      style: GoogleFonts.openSans(fontSize: 16, color: Colors.white70),
                    ),
                    SizedBox(height: 30),
                    if (isSearchingForServer) ...[
                      Center(child: SpinKitWave(color: Colors.white, size: 50.0)),
                      SizedBox(height: 20),
                      Center(
                        child: Text(
                          "Searching for server...",
                          style: GoogleFonts.openSans(fontSize: 14, color: Colors.white70),
                        ),
                      ),
                    ] else ...[
                      if (apiUrl.contains("localhost")) ...[
                        _buildInputField(
                          controller: manualIpController,
                          label: "Enter Backend IP (e.g., 192.168.x.x)",
                          icon: Icons.vpn_key,
                        ),
                        SizedBox(height: 20),
                      ],
                      _buildInputField(
                        controller: emailController,
                        label: "Email",
                        icon: Icons.email,
                      ),
                      SizedBox(height: 20),
                      _buildInputField(
                        controller: passwordController,
                        label: "Password",
                        icon: Icons.lock,
                        obscureText: !_isPasswordVisible,
                        suffixIcon: IconButton(
                          icon: Icon(
                            _isPasswordVisible ? Icons.visibility : Icons.visibility_off,
                            color: Colors.white70,
                          ),
                          onPressed: () => setState(() => _isPasswordVisible = !_isPasswordVisible),
                        ),
                      ),
                      SizedBox(height: 30),
                      Pulse(
                        duration: Duration(seconds: 2),
                        child: ElevatedButton(
                          onPressed: isLoading || isSearchingForServer ? null : login,
                          style: ElevatedButton.styleFrom(
                            backgroundColor: Colors.transparent,
                            padding: EdgeInsets.zero,
                            shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(10)),
                          ),
                          child: Ink(
                            decoration: BoxDecoration(
                              gradient: LinearGradient(
                                colors: [Color(0xFF00B4D8), Color(0xFF0077B6)],
                              ),
                              borderRadius: BorderRadius.circular(10),
                            ),
                            child: Container(
                              width: double.infinity,
                              padding: EdgeInsets.symmetric(vertical: 15),
                              child: Center(
                                child: isLoading
                                    ? SpinKitWave(color: Colors.white, size: 20.0)
                                    : Text(
                                        "Log In",
                                        style: GoogleFonts.openSans(
                                          fontSize: 18,
                                          fontWeight: FontWeight.bold,
                                          color: Colors.white,
                                        ),
                                      ),
                              ),
                            ),
                          ),
                        ),
                      ),
                      SizedBox(height: 20),
                      Center(
                        child: GestureDetector(
                          onTap: () {
                            Navigator.pushNamed(context, '/signup');
                          },
                          child: Text(
                            "New user? Sign up",
                            style: GoogleFonts.openSans(
                              fontSize: 14,
                              color: Color(0xFF00B4D8),
                              decoration: TextDecoration.underline,
                            ),
                          ),
                        ),
                      ),
                    ],
                  ],
                ),
              ),
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildInputField({
    required TextEditingController controller,
    required String label,
    required IconData icon,
    bool obscureText = false,
    Widget? suffixIcon,
  }) {
    return TextField(
      controller: controller,
      obscureText: obscureText,
      style: TextStyle(color: Colors.white),
      decoration: InputDecoration(
        labelText: label,
        labelStyle: GoogleFonts.openSans(color: Colors.white70),
        prefixIcon: Icon(icon, color: Colors.white70),
        suffixIcon: suffixIcon,
        enabledBorder: OutlineInputBorder(
          borderSide: BorderSide(color: Colors.white70, width: 1),
          borderRadius: BorderRadius.circular(10),
        ),
        focusedBorder: OutlineInputBorder(
          borderSide: BorderSide(color: Color(0xFF00B4D8), width: 2),
          borderRadius: BorderRadius.circular(10),
        ),
      ),
    );
  }
}