import 'dart:convert';
import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;
import 'package:shared_preferences/shared_preferences.dart';
import 'package:file_picker/file_picker.dart';
import 'package:google_fonts/google_fonts.dart';

class TamperingScreen extends StatefulWidget {
  final String apiUrl;

  TamperingScreen({required this.apiUrl});

  @override
  _TamperingScreenState createState() => _TamperingScreenState();
}

class _TamperingScreenState extends State<TamperingScreen> with TickerProviderStateMixin {
  bool isLoading = false;
  String? uploadedImagePath;
  late AnimationController _glowController;
  late Animation<double> _glowAnimation;

  @override
  void initState() {
    super.initState();
    _glowController = AnimationController(
      vsync: this,
      duration: const Duration(seconds: 2),
    )..repeat(reverse: true);
    _glowAnimation = Tween<double>(begin: 5, end: 15).animate(
      CurvedAnimation(parent: _glowController, curve: Curves.easeInOut),
    );
  }

  @override
  void dispose() {
    _glowController.dispose();
    super.dispose();
  }

  Future<void> uploadImage() async {
    final result = await FilePicker.platform.pickFiles(type: FileType.image);
    if (result == null || result.files.isEmpty) {
      ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text("No image selected!")));
      return;
    }
    setState(() {
      uploadedImagePath = result.files.first.path;
      print("Image uploaded: $uploadedImagePath");
    });
    ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text("Image uploaded successfully!")));
  }

  Future<void> evaluateTampering() async {
    if (uploadedImagePath == null) {
      ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text("Please upload an image first!")));
      return;
    }

    setState(() => isLoading = true);

    final prefs = await SharedPreferences.getInstance();
    final token = prefs.getString("jwt_token");
    if (token == null) {
      ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text("Please log in first!")));
      setState(() => isLoading = false);
      return;
    }

    final request = http.MultipartRequest(
      "POST",
      Uri.parse("${widget.apiUrl}/api/tampering/detect"),
    );
    request.headers["Authorization"] = "Bearer $token";
    request.files.add(await http.MultipartFile.fromPath("image", uploadedImagePath!));

    try {
      print("Sending tampering detection request to ${widget.apiUrl}/api/tampering/detect with token: $token");
      final response = await request.send();
      final responseBody = await response.stream.bytesToString();
      print("Received response: ${response.statusCode}, Body: $responseBody");

      setState(() => isLoading = false);

      if (response.statusCode == 200) {
        final responseData = jsonDecode(responseBody);
        String originalUrl = responseData["original_url"];
        String maskUrl = responseData["mask_url"];
        print("✅ Tampering detection successful: original=$originalUrl, mask=$maskUrl");
        _showImagePopup(context, originalUrl, maskUrl);
      } else {
        String errorMessage;
        try {
          final responseData = jsonDecode(responseBody);
          errorMessage = responseData["message"] ?? "Unknown error";
        } catch (e) {
          errorMessage = responseBody;
        }
        print("❌ Tampering detection failed: ${response.statusCode}, $errorMessage");
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(content: Text("Failed to detect tampering: $errorMessage")),
        );
      }
    } catch (e) {
      print("❌ Network Error: $e");
      ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text("Network error: $e")));
      setState(() => isLoading = false);
    }
  }

  void _showImagePopup(BuildContext context, String originalUrl, String maskUrl) {
    showDialog(
      context: context,
      builder: (BuildContext context) {
        return AlertDialog(
          title: Text("Tampering Detection Result", style: GoogleFonts.orbitron(fontWeight: FontWeight.bold)),
          content: SingleChildScrollView(
            child: Row(
              mainAxisSize: MainAxisSize.min,
              children: [
                Column(
                  children: [
                    Text("Original Image", style: GoogleFonts.orbitron()),
                    Image.network(
                      originalUrl,
                      width: 250,
                      errorBuilder: (context, error, stackTrace) => Text("Failed to load original: $error"),
                    ),
                  ],
                ),
                SizedBox(width: 20),
                Column(
                  children: [
                    Text("Tampered Mask", style: GoogleFonts.orbitron()),
                    Image.network(
                      maskUrl,
                      width: 250,
                      errorBuilder: (context, error, stackTrace) => Text("Failed to load mask: $error"),
                    ),
                  ],
                ),
              ],
            ),
          ),
          actions: [
            TextButton(
              onPressed: () => Navigator.of(context).pop(),
              child: Text("Close", style: GoogleFonts.orbitron()),
            ),
          ],
        );
      },
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text("Tampering Localization", style: GoogleFonts.orbitron()),
        backgroundColor: Colors.blueGrey[900],
      ),
      body: Container(
        width: double.infinity,
        height: double.infinity,
        decoration: BoxDecoration(
          image: DecorationImage(
            image: AssetImage('assets/images/holographic_background.jpg'),
            fit: BoxFit.cover,
          ),
        ),
        child: Center(
          child: Column(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              _buildAnimatedButton(
                text: "Upload Image",
                imagePath: 'assets/images/upload_button_background.jpg',
                icon: Icons.upload,
                onTap: uploadImage,
              ),
              SizedBox(height: 40),
              _buildAnimatedButton(
                text: "Evaluate",
                imagePath: 'assets/images/evaluate_button_background.jpg',
                icon: Icons.search,
                onTap: evaluateTampering,
              ),
              if (isLoading)
                Padding(
                  padding: EdgeInsets.only(top: 20),
                  child: CircularProgressIndicator(color: Colors.white),
                ),
            ],
          ),
        ),
      ),
    );
  }

  Widget _buildAnimatedButton({required String text, required String imagePath, required IconData icon, required VoidCallback onTap}) {
    return GestureDetector(
      onTap: onTap,
      child: AnimatedBuilder(
        animation: _glowAnimation,
        builder: (context, child) {
          return Container(
            width: 400,
            height: 200,
            decoration: BoxDecoration(
              image: DecorationImage(
                image: AssetImage(imagePath),
                fit: BoxFit.cover,
              ),
              borderRadius: BorderRadius.circular(15),
              border: Border.all(
                color: const Color(0xFF00B4D8),
                width: 3,
              ),
              boxShadow: [
                BoxShadow(
                  color: const Color(0xFF00B4D8).withOpacity(0.4),
                  spreadRadius: _glowAnimation.value,
                  blurRadius: _glowAnimation.value * 2,
                ),
              ],
            ),
            child: Stack(
              alignment: Alignment.center,
              children: [
                Positioned(
                  top: 60,
                  child: Icon(
                    icon,
                    color: Colors.white,
                    size: 40,
                  ),
                ),
                Center(
                  child: Text(
                    text,
                    style: GoogleFonts.orbitron(
                      fontSize: 24,
                      color: Colors.white,
                      fontWeight: FontWeight.bold,
                      shadows: [
                        Shadow(
                          color: Colors.black,
                          blurRadius: 4,
                          offset: Offset(2, 2),
                        ),
                      ],
                    ),
                    textAlign: TextAlign.center,
                  ),
                ),
              ],
            ),
          );
        },
      ),
    );
  }
}