import 'package:flutter/material.dart';

class AnimatedButton extends StatelessWidget {
  final String text;
  final String imagePath;
  final Animation<double> glowAnimation;
  final VoidCallback onTap;

  const AnimatedButton({
    required this.text,
    required this.imagePath,
    required this.glowAnimation,
    required this.onTap,
    super.key,
  });

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTap: onTap,
      child: AnimatedBuilder(
        animation: glowAnimation,
        builder: (context, child) {
          return Container(
            width: 300,
            height: 100,
            decoration: BoxDecoration(
              image: DecorationImage(
                image: AssetImage(imagePath),
                fit: BoxFit.cover,
                onError: (exception, stackTrace) => const AssetImage(
                  'assets/images/default_background.jpg',
                ),
              ),
              borderRadius: BorderRadius.circular(15),
              boxShadow: [
                BoxShadow(
                  color: Colors.blue.withOpacity(0.5),
                  blurRadius: glowAnimation.value,
                  spreadRadius: glowAnimation.value / 2,
                ),
              ],
            ),
            child: Center(
              child: Text(
                text,
                textAlign: TextAlign.center,
                style: const TextStyle(
                  fontSize: 18,
                  color: Colors.white,
                  fontWeight: FontWeight.bold,
                  shadows: [
                    Shadow(
                      color: Colors.black,
                      offset: Offset(1, 1),
                      blurRadius: 3,
                    ),
                  ],
                ),
              ),
            ),
          );
        },
      ),
    );
  }
}