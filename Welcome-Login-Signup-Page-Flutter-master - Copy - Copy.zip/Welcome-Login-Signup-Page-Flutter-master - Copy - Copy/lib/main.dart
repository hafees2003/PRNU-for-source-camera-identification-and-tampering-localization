import 'package:flutter/material.dart';
import 'Screens/Welcome/welcome_screen.dart';
import 'Screens/Login/login_screen.dart';
import 'Screens/Signup/signup_screen.dart';
import 'Screens/Home/home_screen.dart';
import 'Screens/PRNU/prnu_screen.dart';
import 'Screens/Tampering/tampering_screen.dart';

void main() {
  runApp(const MyApp());
}

class MyApp extends StatelessWidget {
  const MyApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      title: 'Cyber Forensics App',
      theme: ThemeData(primarySwatch: Colors.blue),
      initialRoute: '/',
      routes: {
        '/': (_) => WelcomeScreen(),
        '/login': (_) => LoginScreen(),
        '/signup': (_) => SignUpScreen(),
        '/home': (_) => HomeScreen(apiUrl: "http://localhost:8080"),
        '/prnu': (_) => PRNUScreen(),
        '/tampering': (_) => TamperingScreen(apiUrl: "http://localhost:8080"),
      },
    );
  }
}