import tkinter as tk
from tkinter import filedialog
from tkinter import messagebox
from PIL import Image, ImageTk
from test import process_image  # Import the refactored function

def load_image():
    file_path = filedialog.askopenfilename(
        title="Select an Image",
        filetypes=[("Image files", "*.tif;*.tiff;*.jpg;*.jpeg;*.png")]
    )
    if not file_path:
        messagebox.showerror("Error", "No file selected or file type is not supported.")
        return  # No file selected

    try:
        # Load and display input image
        input_img = Image.open(file_path)
        input_image = ImageTk.PhotoImage(input_img.resize((250, 250)))
        input_label.config(image=input_image)
        input_label.image = input_image  # Keep a reference
        input_label.file_path = file_path  # Save file path for later use

    except Exception as e:
        messagebox.showerror("Error", f"An error occurred while loading the image:\n{e}")

def get_results():
    try:
        # Ensure the correct file path is passed to process_image
        file_path = input_label.file_path
        input_img, result_img = process_image(file_path)

        # Display input and result images
        input_tk = ImageTk.PhotoImage(input_img.resize((250, 250)))
        input_label.config(image=input_tk)
        input_label.image = input_tk  # Keep a reference

        result_tk = ImageTk.PhotoImage(result_img.resize((250, 250)))
        output_label.config(image=result_tk)
        output_label.image = result_tk  # Keep a reference

        # Store result image globally for saving
        global processed_result_img
        processed_result_img = result_img

        # Hide all widgets except heading, images, back button, and exit button
        for widget in control_frame.winfo_children():
            widget.pack_forget()

        back_button.pack(side=tk.TOP, anchor="nw", padx=10, pady=10)  # Show back button
        input_label.pack(side=tk.LEFT, padx=10)
        output_label.pack(side=tk.RIGHT, padx=10)
        save_button.pack(pady=10)
        exit_button.pack(pady=10)

    except Exception as e:
        messagebox.showerror("Error", f"An error occurred:\n{e}")

def back_to_main():
    # Reset the view to show controls again
    for widget in control_frame.winfo_children():
        widget.pack(side=tk.LEFT, padx=10)

    input_label.config(image="")
    input_label.image = None
    input_label.file_path = None  # Clear the previous file path

    output_label.config(image="")
    output_label.image = None

    back_button.pack_forget()
    save_button.pack_forget()
    exit_button.pack_forget()

def save_image():
    try:
        if not processed_result_img:
            messagebox.showerror("Error", "No result image to save!")
            return

        save_path = filedialog.asksaveasfilename(
            title="Save Image",
            defaultextension=".png",
            filetypes=[("PNG files", "*.png"), ("JPEG files", "*.jpg"), ("TIFF files", "*.tiff")]
        )
        if save_path:
            processed_result_img.save(save_path)
            messagebox.showinfo("Success", f"Image saved at {save_path}")
    except Exception as e:
        messagebox.showerror("Error", f"Failed to save image:\n{e}")

def exit_program():
    window.destroy()

# Main Window
window = tk.Tk()
window.title("Image Tampering Detection")
window.geometry("800x700")  # Adjusted size for better layout
window.configure(bg="light blue")

# Heading
heading = tk.Label(window, text="Tampering Localization", font=("Helvetica", 20, "bold"), bg="light blue", fg="dark blue")
heading.pack(pady=20)

# Create frames for input and output images, and control buttons
control_frame = tk.Frame(window, bg="light blue")
control_frame.pack(pady=10)  # Controls positioned first

image_frame = tk.Frame(window, bg="light blue")
image_frame.pack(pady=10)  # Image frame comes next

# Load Image Button
load_button = tk.Button(control_frame, text="Select Image", command=load_image, font=("Helvetica", 14, "bold"), padx=20, pady=10, bg="#3498db", fg="white", relief="raised", bd=4)
load_button.pack(side=tk.LEFT, padx=10)

# Result Button
result_button = tk.Button(control_frame, text="Get Results", command=get_results, font=("Helvetica", 14, "bold"), padx=20, pady=10, bg="#2ecc71", fg="white", relief="raised", bd=4)
result_button.pack(side=tk.LEFT, padx=10)

# Input Image (will show after selecting an image)
input_label = tk.Label(image_frame, bg="light blue")
input_label.pack(side=tk.LEFT, padx=10)

# Output Image
output_label = tk.Label(image_frame, bg="light blue")
output_label.pack(side=tk.RIGHT, padx=10)

# Back Button (Initially Hidden)
back_button = tk.Button(window, text="<-", command=back_to_main, font=("Helvetica", 14, "bold"), bg="light blue", fg="dark blue")
back_button.pack_forget()  # Hidden initially

# Save Button (Initially Hidden)
save_button = tk.Button(window, text="Save Image", command=save_image, font=("Helvetica", 14, "bold"), padx=20, pady=10)
save_button.pack_forget()  # Hidden initially

# Exit Button (Initially Hidden)
exit_button = tk.Button(window, text="Exit", command=exit_program, font=("Helvetica", 14, "bold"), padx=20, pady=10)
exit_button.pack_forget()  # Hidden initially

# Run GUI
window.mainloop()
