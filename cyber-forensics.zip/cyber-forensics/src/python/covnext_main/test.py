import os
import warnings
warnings.filterwarnings("ignore")
from mmseg.apis import init_segmentor, inference_segmentor
import numpy as np
from PIL import Image

# Initialize model
config_file = './configs/convnext/convnext_b_test.py'
checkpoint_file = './checkpoints/latest.pth'
model = init_segmentor(config_file, checkpoint_file, device='cuda:0')

def process_image(image_path):
    """
    Processes a single image to generate the segmentation mask.
    
    Args:
        image_path (str): Path to the input image.

    Returns:
        tuple: Input image (PIL), Result mask (PIL).
    """
    try:
        # Perform inference
        result = inference_segmentor(model, image_path)[0]
        
        # Convert input image to PIL format
        input_img = Image.open(image_path)
        
        # Convert result mask to PIL grayscale image
        result_img = Image.fromarray((result * 255).astype(np.uint8))
        
        return input_img, result_img
    except Exception as e:
        raise RuntimeError(f"Error during inference: {e}")
