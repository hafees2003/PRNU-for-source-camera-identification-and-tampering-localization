import argparse
import os
import os.path as osp
import time

import mmcv
import torch
from mmcv.utils import Config

from mmseg.apis import set_random_seed, train_segmentor
from mmseg.datasets import build_dataset
from mmseg.models import build_segmentor
from mmseg.utils import get_root_logger

def parse_args():
    parser = argparse.ArgumentParser(description='Train a segmentor')
    parser.add_argument('--config', default=osp.abspath('./configs/convnext/convnext_b_train.py'), help='train config file path')
    parser.add_argument('--work-dir', default='./log/', help='the dir to save logs and models')
    parser.add_argument('--load-from', help='the checkpoint file to load weights from')
    parser.add_argument('--resume-from', help='the checkpoint file to resume from')
    parser.add_argument('--no-validate', action='store_true', help='skip validation during training')
    parser.add_argument('--gpu-id', type=int, default=0, help='id of GPU to use (for single-GPU training)')
    parser.add_argument('--seed', type=int, default=None, help='random seed')
    parser.add_argument('--deterministic', action='store_true', help='set deterministic options for CUDNN backend')
    parser.add_argument('--auto-resume', action='store_true', help='resume from the latest checkpoint automatically')
    return parser.parse_args()

def main():
    args = parse_args()

    cfg = Config.fromfile(args.config)

    # Check for compatibility with PyTorch and MMCV versions
    assert torch.__version__.startswith('1.8'), "Torch version must be 1.8.0"
    assert mmcv.__version__ == '1.6.2', "MMCV version must be 1.6.2"

    # Enable cudnn_benchmark for deterministic operations
    torch.backends.cudnn.benchmark = cfg.get('cudnn_benchmark', False)

    # Setup work directory for logs and models
    if args.work_dir:
        cfg.work_dir = args.work_dir
    if args.load_from:
        cfg.load_from = args.load_from
    if args.resume_from:
        cfg.resume_from = args.resume_from
    cfg.gpu_ids = [args.gpu_id]

    os.makedirs(osp.abspath(cfg.work_dir), exist_ok=True)

    # Set random seed for reproducibility
    if args.seed is not None:
        set_random_seed(args.seed, deterministic=args.deterministic)
        cfg.seed = args.seed

    log_file = osp.join(cfg.work_dir, f"{time.strftime('%Y%m%d_%H%M%S')}.log")
    logger = get_root_logger(log_file=log_file, log_level=cfg.log_level)

    # Build the model
    model = build_segmentor(
        cfg.model,
        train_cfg=cfg.get('train_cfg'),
        test_cfg=cfg.get('test_cfg')
    )
    model.init_weights()

    # Build the datasets
    datasets = [build_dataset(cfg.data.train)]
    if len(cfg.workflow) == 2:
        val_dataset = cfg.data.val.copy()
        val_dataset.pipeline = cfg.data.train.pipeline
        datasets.append(build_dataset(val_dataset))

    # Train the model
    train_segmentor(
        model,
        datasets,
        cfg,
        distributed=False,
        validate=not args.no_validate
    )

if __name__ == '__main__':
    main()
