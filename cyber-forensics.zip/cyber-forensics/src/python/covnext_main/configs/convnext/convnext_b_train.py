import os
import os.path as osp
import torch
import random
import numpy as np
from mmcv import Config
from mmcv.runner import set_random_seed

# Set the seed for reproducibility
seed = 42

# Base configuration paths
_base_ = [
    'C:/Users/hafee/Videos/ConvNeXtFF-main/configs/_base_/models/models.py', 
    'C:/Users/hafee/Videos/ConvNeXtFF-main/configs/_base_/datasets/my_dataset.py',
    'C:/Users/hafee/Videos/ConvNeXtFF-main/configs/_base_/default_runtime.py', 
    'C:/Users/hafee/Videos/ConvNeXtFF-main/configs/_base_/schedules/schedule_20k.py'
]

# Resolving potential circular imports in _base_
for base in _base_:
    base_path = osp.abspath(base)
    print(f"Checking base path: {base_path}")  # Debugging path resolution
    if not osp.exists(base_path):
        raise FileNotFoundError(f"Base configuration file not found: {base_path}")

# Load configuration from file
cfg = Config.fromfile('./configs/convnext/convnext_b_train.py')

# Crop size for input images
crop_size = (512, 512)

# Model configuration
model = dict(
    decode_head=dict(in_channels=[128, 256, 512, 1024], num_classes=2),
    test_cfg=dict(mode='slide', crop_size=crop_size, stride=(341, 341)),
)

# Optimizer configuration
optimizer = dict(
    constructor='LearningRateDecayOptimizerConstructor',
    _delete_=True,
    type='AdamW',
    lr=0.0001,
    betas=(0.9, 0.999),
    weight_decay=0.05,
    paramwise_cfg={
        'decay_rate': 0.9,
        'decay_type': 'stage_wise',
        'num_layers': 12
    }
)

# Learning rate configuration
lr_config = dict(
    _delete_=True,
    policy='poly',
    warmup='linear',
    warmup_iters=1500,
    warmup_ratio=1e-6,
    power=1.0,
    min_lr=0.0,
    by_epoch=False
)

# Dataset configuration
data = dict(samples_per_gpu=2)

# Optimizer hook for mixed precision
optimizer_config = dict(type='Fp16OptimizerHook', loss_scale='dynamic')

# Mixed precision training configuration
fp16 = dict()

# Set the device for model training
device = 'cuda' if torch.cuda.is_available() else 'cpu'

# Set random seed for reproducibility
random.seed(seed)
np.random.seed(seed)
torch.manual_seed(seed)
torch.cuda.manual_seed_all(seed)

# Set random seed for MMCV
set_random_seed(seed, deterministic=True)

# Ensure the seed is added to the config for consistency
cfg.seed = seed
cfg.device = device

# Optionally, print out the configuration to ensure everything is loaded correctly
print(cfg)

# Optionally, ensure the base configurations are correctly integrated
# You can check specific parts of the base config if needed
