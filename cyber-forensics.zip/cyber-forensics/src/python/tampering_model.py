import sys
import os
import numpy as np
from mmseg.apis import init_segmentor, inference_segmentor
from PIL import Image
import warnings
import torch

# Suppress UserWarning from MMSegmentation
warnings.filterwarnings("ignore", category=UserWarning)

# Load pre-trained model
CONFIG_FILE = r"C:\Users\hafee\Music\cyber-forensics\src\python\Main project\configs\convnext\convnext_b_test.py"
CHECKPOINT_FILE = r"C:\Users\hafee\Music\cyber-forensics\src\python\Main project\checkpoints\latest.pth"
UPLOADS_DIR = r"C:\Users\hafee\Music\cyber-forensics\src\uploads"

try:
    # Try GPU first, fall back to CPU if out of memory or unavailable
    if torch.cuda.is_available():
        print("Clearing GPU memory...", file=sys.stderr)  # Debug to stderr
        torch.cuda.empty_cache()
        device = 'cuda:0'
        try:
            model = init_segmentor(CONFIG_FILE, CHECKPOINT_FILE, device=device)
            print(f"Model loaded on {device}", file=sys.stderr)  # Debug to stderr
        except torch.cuda.OutOfMemoryError:
            print("CUDA out of memory, switching to CPU", file=sys.stderr)
            torch.cuda.empty_cache()
            device = 'cpu'
            model = init_segmentor(CONFIG_FILE, CHECKPOINT_FILE, device=device)
            print(f"Model loaded on {device}", file=sys.stderr)
    else:
        device = 'cpu'
        model = init_segmentor(CONFIG_FILE, CHECKPOINT_FILE, device=device)
        print(f"Model loaded on {device} (no GPU available)", file=sys.stderr)
except Exception as e:
    print(f"Error loading model: {e}", file=sys.stderr)
    sys.exit(1)

def process_image(image_path):
    """Process an image to generate tampering localization map."""
    try:
        # Validate image path
        if not os.path.exists(image_path):
            print(f"Error: Image file not found at {image_path}", file=sys.stderr)
            sys.exit(1)

        # Perform inference
        result = inference_segmentor(model, image_path)
        if isinstance(result, list):
            result = result[0]  # Take first output if list

        # Ensure result is a numpy array and apply threshold
        if not isinstance(result, np.ndarray):
            print(f"Error: Expected numpy array, got {type(result)}", file=sys.stderr)
            sys.exit(1)

        # Convert logits to binary mask (threshold at 0.5)
        result = (result > 0.5).astype(np.uint8)

        # Convert result to an image
        result_img = Image.fromarray(result * 255)  # Scale to 0-255
        os.makedirs(UPLOADS_DIR, exist_ok=True)
        mask_filename = os.path.basename(image_path).replace(".jpg", "_mask.png").replace(".tif", "_mask.png")
        result_img_path = os.path.join(UPLOADS_DIR, mask_filename)
        result_img.save(result_img_path)

        # Output only the mask path to stdout
        print(result_img_path)
        sys.stdout.flush()
    except Exception as e:
        print(f"Error processing image: {e}", file=sys.stderr)
        sys.exit(1)

if __name__ == "__main__":
    if len(sys.argv) < 2:
        print("Error: No image path provided", file=sys.stderr)
        sys.exit(1)
    image_path = sys.argv[1]
    process_image(image_path)