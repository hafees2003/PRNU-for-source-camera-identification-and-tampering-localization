import sys
import os
import json
import numpy as np
import cv2
from PIL import Image
import tensorflow as tf

print(f"TensorFlow version: {tf.__version__}", file=sys.stderr)  # Should be 2.17.0

CAMERAS = ['D06_Apple_iPhone6', 'D08_Samsung_S23', 'D05_Apple_iPhone5c', 'D04_LG_D290', 'D03_Huawei_P9']
FFDNET_MODEL_PATH = r"C:\Users\hafee\Music\cyber-forensics\src\python\models\ffdnet_rgb_optimized.keras"
RESNET_JSON_PATH = r"C:\Users\hafee\Music\cyber-forensics\src\python\models\model.json"
RESNET_WEIGHTS_PATH = r"C:\Users\hafee\Music\cyber-forensics\src\python\models\model_weights.weights.h5"
UPLOADS_DIR = r"C:\Users\hafee\Music\cyber-forensics\src\uploads"

try:
    # Load FFDNet model from .keras file without compiling
    ffdnet_model = tf.keras.models.load_model(FFDNET_MODEL_PATH, compile=False)

    # Load ResNet model
    with open(RESNET_JSON_PATH, "r") as json_file:
        resnet_model_json = json_file.read()
    resnet_model = tf.keras.models.model_from_json(resnet_model_json)
    resnet_model.load_weights(RESNET_WEIGHTS_PATH)

    print("Models loaded successfully", file=sys.stderr)
except Exception as e:
    print(f"Error loading models: {e}", file=sys.stderr)
    sys.exit(1)

def extract_prnu(image_path):
    img = cv2.imread(image_path)
    if img is None:
        print(f"Error: Unable to read image at {image_path}", file=sys.stderr)
        sys.exit(1)
    image = np.float32(img) / 255.0
    image = cv2.cvtColor(image, cv2.COLOR_BGR2RGB)
    image_resized = cv2.resize(image, (224, 224))
    image_input = np.expand_dims(image_resized, axis=0)
    denoised_image = ffdnet_model.predict(image_input, verbose=0)[0]
    prnu = image_resized - denoised_image
    prnu_gray = cv2.cvtColor(prnu, cv2.COLOR_RGB2GRAY)
    prnu_gray = cv2.normalize(prnu_gray, None, 0, 1, cv2.NORM_MINMAX)
    prnu_gray = np.expand_dims(prnu_gray, axis=-1)
    mask_filename = os.path.basename(image_path).replace(".jpg", "_prnu.png").replace(".tif", "_prnu.png")
    mask_path = os.path.join(UPLOADS_DIR, mask_filename)
    os.makedirs(UPLOADS_DIR, exist_ok=True)
    Image.fromarray((prnu_gray.squeeze() * 255).astype(np.uint8)).save(mask_path)
    return prnu_gray, mask_path

def predict_camera(image_path):
    try:
        prnu, mask_path = extract_prnu(image_path)
        prnu_resized = cv2.resize(prnu, (224, 224))
        prnu_expanded = np.expand_dims(prnu_resized, axis=0)
        img = cv2.imread(image_path)
        img_resized = cv2.resize(img, (224, 224)) / 255.0
        img_expanded = np.expand_dims(img_resized, axis=0)
        preds = resnet_model.predict([img_expanded, prnu_expanded], verbose=0)[0]
        predict_idx = np.argmax(preds)
        predicted_camera = CAMERAS[predict_idx]
        confidences = preds.tolist()
        print(mask_path)  # Output mask path to stdout
        # Include camera_labels in the JSON response
        print(json.dumps({"camera": predicted_camera, "confidences": confidences, "camera_labels": CAMERAS}))
        sys.stdout.flush()
    except Exception as e:
        print(f"Error predicting camera: {e}", file=sys.stderr)
        sys.exit(1)

if __name__ == "__main__":
    if len(sys.argv) < 2:
        print("Error: No image path provided", file=sys.stderr)
        sys.exit(1)
    image_path = sys.argv[1]
    predict_camera(image_path)