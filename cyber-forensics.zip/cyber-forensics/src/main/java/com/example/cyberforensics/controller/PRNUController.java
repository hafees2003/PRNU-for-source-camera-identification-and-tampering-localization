package com.example.cyberforensics.controller;

import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;

import java.io.*;
import java.nio.file.*;

@RestController
@RequestMapping("/api/prnu")
@CrossOrigin(origins = "http://localhost:8080")
public class PRNUController {

    private static final String UPLOAD_DIR = "C:\\Users\\hafee\\Music\\cyber-forensics\\src\\uploads";
    private static final String PYTHON_SCRIPT = "C:\\Users\\hafee\\Music\\cyber-forensics\\src\\python\\prnu_predict.py";
    private static final String PYTHON_EXECUTABLE = "C:\\Users\\hafee\\Music\\cyber-forensics\\prnu_env\\Scripts\\python.exe";

    @PostMapping("/predict")
    public ResponseEntity<?> predictCamera(@RequestParam("image") MultipartFile file) {
        try {
            Files.createDirectories(Paths.get(UPLOAD_DIR));
            String imageName = file.getOriginalFilename();
            if (imageName == null) {
                System.err.println("No file name provided");
                return ResponseEntity.status(400).body("{\"message\": \"No file name provided\"}");
            }
            Path imagePath = Paths.get(UPLOAD_DIR, imageName);
            Files.write(imagePath, file.getBytes());
            System.out.println("Image saved at: " + imagePath);

            ProcessBuilder pb = new ProcessBuilder(PYTHON_EXECUTABLE, PYTHON_SCRIPT, imagePath.toString());
            pb.redirectErrorStream(true);
            Process process = pb.start();
            System.out.println("PRNU prediction script started: " + PYTHON_SCRIPT + " with " + PYTHON_EXECUTABLE);

            BufferedReader reader = new BufferedReader(new InputStreamReader(process.getInputStream()));
            StringBuilder output = new StringBuilder();
            String maskImagePath = null;
            String predictionData = null;
            String line;
            while ((line = reader.readLine()) != null) {
                output.append(line).append("\n");
                if (line.contains("_prnu.png")) {  // First line should be mask path
                    maskImagePath = line.trim();
                } else if (line.startsWith("{")) {  // Second line should be JSON
                    predictionData = line.trim();
                }
            }

            int exitCode = process.waitFor();
            System.out.println("PRNU script exited with code: " + exitCode);
            if (exitCode == 0) {
                if (maskImagePath == null || predictionData == null) {
                    System.err.println("PRNU script returned insufficient output: " + output.toString());
                    return ResponseEntity.status(500).body("{\"message\": \"PRNU script returned insufficient output: " + output.toString() + "\"}");
                }
                String originalUrl = "http://localhost:8080/uploads/" + imageName;
                String maskUrl = "http://localhost:8080/uploads/" + new File(maskImagePath).getName();
                System.out.println("PRNU prediction successful: original=" + originalUrl + ", mask=" + maskUrl + ", data=" + predictionData);
                String jsonResponse = "{\"original_url\": \"" + originalUrl + "\", \"mask_url\": \"" + maskUrl + "\", \"prediction\": " + predictionData + "}";
                return ResponseEntity.ok()
                        .contentType(MediaType.APPLICATION_JSON)
                        .body(jsonResponse);
            } else {
                String errorOutput = output.toString().trim();
                System.err.println("PRNU script failed with exit code " + exitCode + ": " + errorOutput);
                return ResponseEntity.status(500).body("{\"message\": \"PRNU prediction failed: " + errorOutput + "\"}");
            }
        } catch (Exception e) {
            System.err.println("Error processing PRNU prediction: " + e.getMessage());
            return ResponseEntity.status(500).body("{\"message\": \"Error processing PRNU prediction: " + e.getMessage() + "\"}");
        }
    }
}