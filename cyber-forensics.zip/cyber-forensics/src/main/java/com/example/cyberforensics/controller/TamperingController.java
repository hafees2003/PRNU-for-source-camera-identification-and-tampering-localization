package com.example.cyberforensics.controller;

import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;

import java.io.*;
import java.nio.file.*;

@RestController
@RequestMapping("/api/tampering")
@CrossOrigin(origins = "http://localhost:8080")
public class TamperingController {

    private static final String UPLOAD_DIR = "C:\\Users\\hafee\\Music\\cyber-forensics\\src\\uploads";
    private static final String PYTHON_SCRIPT = "C:\\Users\\hafee\\Music\\cyber-forensics\\src\\python\\tampering_model.py";
    private static final String PYTHON_EXECUTABLE = "C:\\Users\\hafee\\Music\\cyber-forensics\\tampering_env\\Scripts\\python.exe";

    @PostMapping("/detect")
    public ResponseEntity<?> detectTampering(@RequestParam("image") MultipartFile file) {
        try {
            Files.createDirectories(Paths.get(UPLOAD_DIR));
            String imageName = file.getOriginalFilename();
            if (imageName == null) {
                System.err.println("No file name provided");
                return ResponseEntity.status(400).body("{\"message\": \"No file name provided\"}");
            }
            Path imagePath = Paths.get(UPLOAD_DIR, imageName);
            Files.write(imagePath, file.getBytes());
            System.out.println("Image saved at: " + imagePath);

            ProcessBuilder pb = new ProcessBuilder(PYTHON_EXECUTABLE, PYTHON_SCRIPT, imagePath.toString());
            pb.redirectErrorStream(true);  // Merge stderr with stdout for logging
            Process process = pb.start();
            System.out.println("Python script started: " + PYTHON_SCRIPT + " with " + PYTHON_EXECUTABLE);

            BufferedReader reader = new BufferedReader(new InputStreamReader(process.getInputStream()));
            StringBuilder output = new StringBuilder();
            String maskImagePath = null;
            String line;
            while ((line = reader.readLine()) != null) {
                output.append(line).append("\n");
                // Assume the last non-debug line is the mask path (adjust if needed)
                if (!line.contains("Model loaded") && !line.contains("Clearing GPU") && !line.trim().isEmpty()) {
                    maskImagePath = line.trim();
                }
            }

            int exitCode = process.waitFor();
            System.out.println("Python script exited with code: " + exitCode);
            if (exitCode == 0) {
                if (maskImagePath == null || maskImagePath.isEmpty()) {
                    System.err.println("Python script returned no valid mask path: " + output.toString());
                    return ResponseEntity.status(500).body("{\"message\": \"Python script returned no valid mask path: " + output.toString() + "\"}");
                }
                System.out.println("Mask image path from Python: " + maskImagePath);
                String originalUrl = "http://localhost:8080/uploads/" + imageName;
                String maskUrl = "http://localhost:8080/uploads/" + new File(maskImagePath).getName();
                System.out.println("Tampering detection successful: original=" + originalUrl + ", mask=" + maskUrl);
                String jsonResponse = "{\"original_url\": \"" + originalUrl + "\", \"mask_url\": \"" + maskUrl + "\"}";
                return ResponseEntity.ok()
                        .contentType(MediaType.APPLICATION_JSON)
                        .body(jsonResponse);
            } else {
                String errorOutput = output.toString().trim();
                System.err.println("Python script failed with exit code " + exitCode + ": " + errorOutput);
                return ResponseEntity.status(500).body("{\"message\": \"Model execution failed: " + errorOutput + "\"}");
            }
        } catch (Exception e) {
            System.err.println("Error processing image: " + e.getMessage());
            return ResponseEntity.status(500).body("{\"message\": \"Error processing image: " + e.getMessage() + "\"}");
        }
    }
}