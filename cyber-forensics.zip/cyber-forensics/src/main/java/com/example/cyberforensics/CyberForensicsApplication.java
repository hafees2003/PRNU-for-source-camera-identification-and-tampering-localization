package com.example.cyberforensics;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.event.ContextRefreshedEvent;
import org.springframework.context.event.EventListener;
import javax.annotation.PostConstruct;
import javax.annotation.PreDestroy; // Added this import
import java.net.InetAddress;
import javax.jmdns.JmDNS;
import javax.jmdns.ServiceInfo;

@SpringBootApplication
@ComponentScan(basePackages = {
    "com.example.cyberforensics.config",
    "com.example.cyberforensics.controller",
    "com.example.cyberforensics.exception",
    "com.example.cyberforensics.model",
    "com.example.cyberforensics.repository",
    "com.example.cyberforensics.security"
})
public class CyberForensicsApplication {

    private JmDNS jmdns;

    public static void main(String[] args) {
        SpringApplication.run(CyberForensicsApplication.class, args);
    }

    @PostConstruct
    public void registerService() {
        try {
            // Create JmDNS instance
            jmdns = JmDNS.create(InetAddress.getLocalHost());
            // Register HTTP service
            ServiceInfo serviceInfo = ServiceInfo.create(
                "_http._tcp.local.", // Service type
                "CyberForensicsAPI", // Service name
                8080,                // Port
                "Cyber Forensics Backend" // Description
            );
            jmdns.registerService(serviceInfo);
            System.out.println("JmDNS Service Registered: " + serviceInfo.getName() + " at " + serviceInfo.getURL());
        } catch (Exception e) {
            System.err.println("Error registering JmDNS service: " + e.getMessage());
            e.printStackTrace();
        }
    }

    @EventListener
    public void onApplicationEvent(ContextRefreshedEvent event) {
        System.out.println("Application context refreshed. Total beans: " +
            event.getApplicationContext().getBeanDefinitionCount());
        boolean authControllerExists = event.getApplicationContext().containsBean("authController");
        System.out.println("AuthController registered: " + authControllerExists);
    }

    @PreDestroy
    public void unregisterService() {
        if (jmdns != null) {
            jmdns.unregisterAllServices();
            try {
                jmdns.close();
                System.out.println("JmDNS Service Unregistered");
            } catch (Exception e) {
                System.err.println("Error unregistering JmDNS service: " + e.getMessage());
            }
        }
    }
}