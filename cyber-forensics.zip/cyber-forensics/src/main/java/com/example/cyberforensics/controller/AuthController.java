package com.example.cyberforensics.controller;

import com.example.cyberforensics.model.LoginRequest;
import com.example.cyberforensics.model.User;
import com.example.cyberforensics.repository.UserRepository;
import com.example.cyberforensics.security.JwtUtil;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.web.bind.annotation.*;
import javax.annotation.PostConstruct;
import java.util.HashMap;
import java.util.Map;
import java.util.Optional;

@RestController
@RequestMapping("/api/auth")
@CrossOrigin(origins = "*")
public class AuthController {

    @Autowired
    private UserRepository userRepository;

    @Autowired
    private JwtUtil jwtUtil;

    private final BCryptPasswordEncoder passwordEncoder = new BCryptPasswordEncoder();

    @PostConstruct
    public void init() {
        System.out.println("AuthController has been initialized successfully");
    }

    @PostMapping("/signup")
    public ResponseEntity<Map<String, String>> signup(@RequestBody User user) {
        Map<String, String> response = new HashMap<>();
        Optional<User> existingUser = userRepository.findByEmail(user.getEmail());
        if (existingUser.isPresent()) {
            response.put("message", "Email already registered!");
            return ResponseEntity.status(400).body(response);
        }
        user.setPassword(passwordEncoder.encode(user.getPassword()));
        userRepository.save(user);
        response.put("message", "Signup successful!");
        return ResponseEntity.status(201).body(response);
    }

    @PostMapping("/login")
    public ResponseEntity<Map<String, String>> login(@RequestBody LoginRequest loginRequest) {
        Map<String, String> response = new HashMap<>();
        try {
            System.out.println("Login attempt for email: " + loginRequest.getEmail());
            Optional<User> existingUser = userRepository.findByEmail(loginRequest.getEmail());
            System.out.println("User found: " + existingUser.isPresent());

            if (existingUser.isPresent()) {
                User user = existingUser.get();
                System.out.println("Stored password: " + user.getPassword());
                System.out.println("Provided password: " + loginRequest.getPassword());

                if (passwordEncoder.matches(loginRequest.getPassword(), user.getPassword())) {
                    System.out.println("Password matches, generating token...");
                    String token = jwtUtil.generateToken(user.getEmail());
                    response.put("message", "Login successful");
                    response.put("token", token);
                    return ResponseEntity.ok(response);
                } else {
                    System.out.println("Password does not match");
                    response.put("message", "Invalid email or password!");
                    return ResponseEntity.status(401).body(response);
                }
            }
            System.out.println("User not found");
            response.put("message", "User not found!");
            return ResponseEntity.status(404).body(response);
        } catch (Exception e) {
            System.err.println("Error in login: " + e.getMessage());
            e.printStackTrace();
            response.put("message", "Internal server error: " + e.getMessage());
            return ResponseEntity.status(500).body(response);
        }
    }
}