package com.example.cyberforensics;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest(classes = CyberForensicsApplication.class)
class CyberForensicsApplicationTests {

    @Test
    void contextLoads() {
    }

}
